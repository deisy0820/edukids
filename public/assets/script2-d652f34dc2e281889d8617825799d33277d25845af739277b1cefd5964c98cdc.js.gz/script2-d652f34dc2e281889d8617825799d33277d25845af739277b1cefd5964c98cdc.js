document).ready( function(){

      var morado=false,azul=false,rojo=false,amarillo=false;
        


         $('.verde').mouseup( function(){
             
              $('audio')[0].play();
              verde=true;
              
          })

          $('.azul').mouseup( function(){
             
              $('audio')[1].play();
              azul=true;
           })
              $('.amarillo').mouseup( function(){
             
              $('audio')[2].play();
              amarillo=true;
              
          })


          $('.morado').mouseup( function(){
             
              $('audio')[4].play();
               morado=true;


                 })
    
         /*$('.verde2').mouseup( function(){
             
              $('audio')[1].play();
              verde=true;
              
         //  })

                
              
          })


        
        

          $('.naranja').mouseup( function(){
             
              $('audio')[5].play();
              narajado=true;
              
          })
          $('.cafe').mouseup( function(){
             
              $('audio')[6].play();
              cafe=true;
              
          })
          $('.cafe2').mouseup( function(){
             
              $('audio')[7].play();
              cafe=true;
              
          })
          $('.rosa').mouseup( function(){
             
              $('audio')[8].play();
              rosa=true;
              
          })
          $('.blanco').mouseup( function(){
             
              $('audio')[9].play();
              blanco=true;
              
          })
          $('.negro').mousemove( function(){
             
              $('audio')[10].play();
              rosado=true;
              
          })
          $('.negro2').mousemove( function(){
             
              $('audio')[11].play();
              rosado=true;
              
          }) */




   })
 
;
